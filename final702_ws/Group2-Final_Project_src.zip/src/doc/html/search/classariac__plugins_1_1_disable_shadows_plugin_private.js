var classariac__plugins_1_1_disable_shadows_plugin_private =
[
    [ "first_update_", "classariac__plugins_1_1_disable_shadows_plugin_private.html#a70d50cc59244b5f2b165964b61daac21", null ],
    [ "ros_node_", "classariac__plugins_1_1_disable_shadows_plugin_private.html#aee670a71c0fb928c88a07c4ad46f5dba", null ],
    [ "scene_", "classariac__plugins_1_1_disable_shadows_plugin_private.html#aad45fa3cd37e9ee846a3cc90ce1751f9", null ],
    [ "update_connection_", "classariac__plugins_1_1_disable_shadows_plugin_private.html#ad80e648cc90d2cdc28c8e9946d47eda8", null ],
    [ "visual_", "classariac__plugins_1_1_disable_shadows_plugin_private.html#a7c12894ed9be4b719ac6bd90a0b0c4ab", null ]
];