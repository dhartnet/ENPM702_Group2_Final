var searchData=
[
  ['calculate_5fangular_5fvelocity_5',['calculate_angular_velocity',['../classrobot__target__interface_1_1_robot_target_server.html#af8959e8460bc2ad83e0a31e6e6c7815c',1,'robot_target_interface::RobotTargetServer']]],
  ['compute_5fdistance_5fto_5fgoal_6',['compute_distance_to_goal',['../classrobot__target__interface_1_1_robot_target_server.html#a1bb4dc0941e577d1bf8c168bbb944fdf',1,'robot_target_interface::RobotTargetServer']]],
  ['convert_5fpart_5fcolor_5fto_5fint_7',['convert_part_color_to_int',['../classfinal__project_1_1environment__startup_1_1_environment_startup.html#ac19c13e6eee46750e3e2b729bdeb0596',1,'final_project::environment_startup::EnvironmentStartup']]],
  ['convert_5fpart_5ftype_5fto_5fint_8',['convert_part_type_to_int',['../classfinal__project_1_1environment__startup_1_1_environment_startup.html#a4f41e9e495a5ce7c13b658e5271f1c1c',1,'final_project::environment_startup::EnvironmentStartup']]]
];
