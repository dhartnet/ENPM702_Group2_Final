var classrobot__target__interface_1_1_robot_target_server =
[
    [ "__init__", "classrobot__target__interface_1_1_robot_target_server.html#ac7a1579925baaa162aaa96b2109f2cb9", null ],
    [ "adjust_robot_motion", "classrobot__target__interface_1_1_robot_target_server.html#af251612e435975ee62810f3c4230c713", null ],
    [ "calculate_angular_velocity", "classrobot__target__interface_1_1_robot_target_server.html#af8959e8460bc2ad83e0a31e6e6c7815c", null ],
    [ "compute_distance_to_goal", "classrobot__target__interface_1_1_robot_target_server.html#a1bb4dc0941e577d1bf8c168bbb944fdf", null ],
    [ "execute_cb", "classrobot__target__interface_1_1_robot_target_server.html#aeac0c31b8d8ce16b6a61a2175c047fb6", null ],
    [ "goal_cb", "classrobot__target__interface_1_1_robot_target_server.html#ad312a8b1ee52176c28fce6137a562916", null ],
    [ "odometry_cb", "classrobot__target__interface_1_1_robot_target_server.html#a89b27521adcb3c368815b3844c67e7d2", null ],
    [ "stop_robot", "classrobot__target__interface_1_1_robot_target_server.html#ab9c4219079037482753a4b60d06e1878", null ]
];