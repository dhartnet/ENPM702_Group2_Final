var class_robot_target_client =
[
    [ "RobotTargetClient", "class_robot_target_client.html#a4140ba604f50699f3eec6eb64101ae4f", null ],
    [ "x_pos_", "class_robot_target_client.html#a55ae562ec3e7ddd541579da92438f541", null ]
];