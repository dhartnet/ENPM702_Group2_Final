var class_utils =
[
    [ "Utils", "class_utils.html#a452e78692c87ed5c7c993b6c6ac4981a", null ],
    [ "~Utils", "class_utils.html#afa5e70facffc286607498e7edb639b8a", null ],
    [ "set_euler_from_quaternion", "class_utils.html#ab41d9930be1d94b7fe72fbbea2f8b3ad", null ],
    [ "set_quaternion_from_euler", "class_utils.html#ab0926ab8fcd6b3f96e9b4ec7ba907489", null ]
];